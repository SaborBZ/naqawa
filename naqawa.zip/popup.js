// ضع هنا رابط موقعك بعد نشره على GitHub Pages أو أي استضافة
const WEBSITE_URL = "https://saborbz.github.io/naqawa/";

document.addEventListener('DOMContentLoaded', () => {
    const btnLocal = document.getElementById('btnModeLocal');
    const btnCloud = document.getElementById('btnModeCloud');
    const cloudGroup = document.getElementById('cloudInputGroup');
    const serverInput = document.getElementById('serverUrl');
    const actionBtn = document.getElementById('actionBtn');
    const statusDiv = document.getElementById('status');
    const helpLink = document.getElementById('helpLink');

    let currentMode = "local";

    // فتح موقع الشرح في تبويب جديد
    helpLink.addEventListener('click', (e) => {
        e.preventDefault();
        chrome.tabs.create({ url: WEBSITE_URL });
    });

    chrome.storage.local.get(['naqawa_mode', 'naqawa_server_url'], (res) => {
        if (res.naqawa_server_url) {
            serverInput.value = res.naqawa_server_url;
        }
        if (res.naqawa_mode === "cloud") {
            setMode("cloud");
        } else {
            setMode("local");
        }
    });

    function setMode(mode) {
        currentMode = mode;
        chrome.storage.local.set({ naqawa_mode: mode });

        if (mode === "local") {
            btnLocal.classList.add('active');
            btnCloud.classList.remove('active');
            cloudGroup.style.display = 'none';
            statusDiv.innerText = "جاهز للمعالجة عبر معالج جهازك 💻";
        } else {
            btnCloud.classList.add('active');
            btnLocal.classList.remove('active');
            cloudGroup.style.display = 'block';
            statusDiv.innerText = "جاهز للمعالجة عبر السحابة ☁️";
        }
    }

    btnLocal.addEventListener('click', () => setMode("local"));
    btnCloud.addEventListener('click', () => setMode("cloud"));

    actionBtn.addEventListener('click', async () => {
        let finalUrl = "";

        if (currentMode === "local") {
            finalUrl = "http://127.0.0.1:8000";
        } else {
            finalUrl = serverInput.value.trim().replace(/\/+$/, "");
            if (!finalUrl) {
                statusDiv.innerText = "❌ يرجى إدخال رابط خادم Colab!";
                return;
            }
            chrome.storage.local.set({ naqawa_server_url: finalUrl });
        }

        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.url || !tab.url.includes("youtube.com/watch")) {
            statusDiv.innerText = "❌ يرجى فتح مقطع فيديو على يوتيوب أولاً!";
            return;
        }

        actionBtn.innerText = "جاري البدء ⏳";
        actionBtn.classList.add("processing");
        statusDiv.innerText = currentMode === "local"
        ? "جاري المعالجة محلياً عبر جهازك..."
        : "جاري المعالجة عبر السحابة...";

        chrome.tabs.sendMessage(tab.id, { action: "PROCESS_CLOUD_AI", serverUrl: finalUrl }, (res) => {
            actionBtn.innerText = "عزل الموسيقى 🎧";
            actionBtn.classList.remove("processing");

            if (chrome.runtime.lastError) {
                statusDiv.innerHTML = "قم بتحديث صفحة اليوتيوب <b>(F5)</b> ثم جرب مجدداً.";
                return;
            }

            if (res && res.success) {
                statusDiv.innerText = "✅ تم عزل الموسيقى وبدء المزامنة!";
            } else {
                statusDiv.innerText = "❌ " + (res ? res.error : "فشل الاتصال بالسيرفر");
            }
        });
    });
});
