let currentVocalAudio = null;
let syncInterval = null;
let liveTimerInterval = null;
let startTime = null;

function createProgressBox() {
    let box = document.getElementById('ai-vocal-progress-box');
    if (!box) {
        box = document.createElement('div');
        box.id = 'ai-vocal-progress-box';
        box.style.cssText = `
        position: absolute; top: 25px; left: 25px; z-index: 99999;
        background: rgba(13, 20, 18, 0.95); color: #fff; padding: 16px 20px;
        border-radius: 12px; font-family: system-ui, -apple-system, sans-serif;
        box-shadow: 0 8px 24px rgba(0,0,0,0.7); direction: rtl; border: 1px solid #00a86b;
        width: 280px; backdrop-filter: blur(8px); transition: all 0.3s ease;
        `;

        box.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
        <span style="font-size: 13px; font-weight: bold; color: #d4af37;">نقاوة (معالجة السحابة)</span>
        <span id="ai-percent-num" style="font-size: 13px; font-weight: bold; color: #00a86b;">0%</span>
        </div>

        <div style="width: 100%; background: #16221f; height: 8px; border-radius: 4px; overflow: hidden; margin-bottom: 8px; border: 1px solid #243530;">
        <div id="ai-progress-bar-fill" style="width: 0%; height: 100%; background: #00a86b; transition: width 0.2s ease;"></div>
        </div>

        <div style="display: flex; justify-content: space-between; font-size: 11px; color: #a0aec0;">
        <span id="ai-stage-text">جاري بدء المعالجة...</span>
        <span id="ai-timer-text" style="color: #d4af37; font-weight: bold; font-family: monospace;">⏱️ 0.0 ث</span>
        </div>
        `;

        const player = document.querySelector('#movie_player') || document.body;
        player.appendChild(box);
    }
    box.style.display = 'block';
    box.style.borderColor = '#00a86b';
    return box;
}

function updateProgressUI(percent, text, timeText = null, isError = false) {
    const fill = document.getElementById('ai-progress-bar-fill');
    const num = document.getElementById('ai-percent-num');
    const txt = document.getElementById('ai-stage-text');
    const timerTxt = document.getElementById('ai-timer-text');
    const box = document.getElementById('ai-vocal-progress-box');

    if (fill) fill.style.width = `${percent}%`;
    if (num) num.innerText = `${percent}%`;
    if (txt && text) txt.innerText = text;
    if (timerTxt && timeText !== null) timerTxt.innerText = timeText;

    if (isError && box && fill) {
        box.style.borderColor = '#e50914';
        fill.style.background = '#e50914';
        if (num) num.style.color = '#e50914';
        if (timerTxt) timerTxt.innerText = "❌ خطأ";
    }
}

function setupSyncEngine(video, audioUrl, totalTime) {
    if (currentVocalAudio) {
        currentVocalAudio.pause();
        currentVocalAudio.remove();
    }

    currentVocalAudio = new Audio(audioUrl);
    currentVocalAudio.preload = 'auto';

    video.muted = true;

    video.addEventListener('play', () => {
        if (currentVocalAudio.paused) currentVocalAudio.play();
    });
        video.addEventListener('pause', () => {
            if (!currentVocalAudio.paused) currentVocalAudio.pause();
        });

            const syncTime = () => {
                currentVocalAudio.currentTime = video.currentTime;
            };
            video.addEventListener('seeking', syncTime);
            video.addEventListener('seeked', syncTime);

            video.addEventListener('ratechange', () => {
                currentVocalAudio.playbackRate = video.playbackRate;
            });
            video.addEventListener('volumechange', () => {
                currentVocalAudio.volume = video.volume;
            });

            if (syncInterval) clearInterval(syncInterval);
            syncInterval = setInterval(() => {
                if (!video.paused && !currentVocalAudio.paused) {
                    if (Math.abs(currentVocalAudio.currentTime - video.currentTime) > 0.08) {
                        currentVocalAudio.currentTime = video.currentTime;
                    }
                }
            }, 100);

            currentVocalAudio.currentTime = video.currentTime;
            currentVocalAudio.playbackRate = video.playbackRate;
            if (!video.paused) {
                currentVocalAudio.play();
            }

            updateProgressUI(100, "تم تنقية الصوت بنجاح ✨", `⚡ في ${totalTime} ث`);
            setTimeout(() => {
                const box = document.getElementById('ai-vocal-progress-box');
                if (box) box.style.display = 'none';
            }, 2500);
}

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.action === "PROCESS_CLOUD_AI") {
        const video = document.querySelector('video');
        if (!video) {
            sendResponse({ success: false, error: "لم يتم العثور على مشغل الفيديو" });
            return;
        }

        createProgressBox();
        startTime = Date.now();

        if (liveTimerInterval) clearInterval(liveTimerInterval);

        liveTimerInterval = setInterval(() => {
            const elapsedSeconds = ((Date.now() - startTime) / 1000).toFixed(1);
            const dynamicPct = Math.min(95, Math.round(95 * (1 - Math.exp(-elapsedSeconds / 6))));

            let stage = "جاري سحب مسار الصوت...";
            if (dynamicPct > 30 && dynamicPct <= 75) stage = "جاري عزل الموسيقى بـ Demucs...";
            if (dynamicPct > 75) stage = "جاري تحضير المسار والمزامنة...";

            updateProgressUI(dynamicPct, stage, `⏱️ ${elapsedSeconds} ث`);
        }, 100);

        const cleanServerUrl = req.serverUrl.replace(/\/+$/, "");
        const videoUrl = window.location.href;

        fetch(`${cleanServerUrl}/process?url=${encodeURIComponent(videoUrl)}`)
        .then(async r => {
            const data = await r.json().catch(() => ({ detail: `خطأ اتصال (${r.status})` }));
            if (!r.ok) {
                throw new Error(data.detail || `رمز الخطأ: ${r.status}`);
            }
            return data;
        })
        .then(data => {
            clearInterval(liveTimerInterval);
            const totalDuration = ((Date.now() - startTime) / 1000).toFixed(1);

            if (data.status === "ready") {
                const audioStreamUrl = `${cleanServerUrl}/audio/${data.video_id}`;
                setupSyncEngine(video, audioStreamUrl, totalDuration);
                sendResponse({ success: true });
            } else {
                throw new Error("فشلت معالجة مسار الصوت");
            }
        })
        .catch(err => {
            clearInterval(liveTimerInterval);
            console.error(err);
            updateProgressUI(0, err.message, "❌ فشل", true);
            sendResponse({ success: false, error: err.message });
        });

        return true;
    }
});
